<?php
    if(isset($_POST['submit']))
    {

        // print_r($_POST['email']);
        // print_r('<br>');
        // print_r($_POST['password']);

        include_once('config.php');

        $email = $_POST['email'];
        $password = $_POST['password'];

        $result = mysqli_query($conexao, "INSERT INTO usuarios(email,password)
        VALUES('$email','$password')");
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <section class="header">
            <h2>Login</h2>
        </section>

        <form id="form" class="form">

            <div class="form-content">
                <label for="email">Email</label>
                <input type="email" id="email" placeholder="Digite o seu email">
                <a>Mensagem de erro</a>
            </div>

            <div class="form-content">
                <label for="password">Senha </label>
                <input type="password" id="password" placeholder="Digite uma senha">
                <a>Mensagem de erro</a>
            </div>


            <button type="submit">Cadastrar</button>

        </form>
    </div>

    <script src="jscript.js"></script>

</body>
</html>