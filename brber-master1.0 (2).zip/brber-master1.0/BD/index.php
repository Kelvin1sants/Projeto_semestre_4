<?php
    if(isset($_POST['submit']))
    {

        // print_r($_POST['username']);
        // print_r('<br>');
        // print_r($_POST['email']);
        // print_r('<br>');
        // print_r($_POST['password']);
        // print_r('<br>');
        // print_r($_POST['passwordConfirmation']);

        include_once('config.php');

        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $passwordConfirmation = $_POST['passwordConfirmation'];

        $result = mysqli_query($conexao, "INSERT INTO usuarios(username,email,password,passwordConfirmation)
        VALUES('$username','$email','$password','$passwordConfirmation')");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Cadastro</title>
</head>
<body>

   
    
    <div class="container">



        <section class="header">
            <h2>Cadastar</h2>
        </section>

        <form action="index.php" method="POST" id="form" class="form">

            <div class="form-content">
                <label for="username">Nome completo</label>
                <input type="text" name="username" id="username" placeholder="Digite o seu nome">
                <a>Mensagem de erro</a>
            </div>

            <div class="form-content">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" placeholder="Digite o seu email">
                <a>Mensagem de erro</a>
            </div>

            <div class="form-content">
                <label for="password">Senha </label>
                <input type="password" name="password" id="password" placeholder="Digite uma senha">
                <a>Mensagem de erro</a>
            </div>

            <div class="form-content">
                <label for="password-confirmation">Confirme a senha</label>
                <input type="password" name="passwordConfirmation" id="password-confirmation"
                placeholder="Digite a senha mais uma vez">
                <a>Mensagem de erro</a>
            </div>

            <input type="submit" name="submit" id="submit">

        </form>
    </div>

    <script src="script.js"></script>

</body>
</html>