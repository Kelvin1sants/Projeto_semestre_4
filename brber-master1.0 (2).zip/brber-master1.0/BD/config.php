<?php
$dbHost = 'Localhost';
$dbUsername = 'root';
$dbPassword = '4987';
$dbName = 'formbarber'; 

$conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

    // if($conexao->connect_errno)
    // {
    //     echo"erro";
    // }
    // else
    // {
    //     echo "Conexão efetuada com sucesso";
    // }

    ?>